

function check(){
    var  message, x;
    message = document.getElementById("number");
    message.innerHTML = "";
    x = document.getElementById("limit").value;
    try { 
        console.log("x: " + x);
        if(x == "") throw "is Empty";
        if(isNaN(x)) throw "is not a number.";
        if(x > 1000000) throw "cannot be more than 1000000.";
        if(x < 0) throw "cannot be less than 0.";
    }
    catch(err) {
        message.innerHTML = "Input " + err;
    }
    
    randomNumber(x);
}


function flip() {
  return Math.random() >= 0.5;
}

function randomNumber(n){
    console.log("n" + n);

    let s0 = 0;
    let s1 = 0;

    if(flip()){
        s1 = 1;
        s0 = 2;
    } 
    else{
        s1 = 12;
        s0 = 23;
    }

  var random = pseudoRandomNumber(s0, s1);
  if(random > n)
    {
       random = random % n;
    }

  document.getElementById('number').innerHTML = random;  
}


// Used the underlying implementation of Math.random() by browsers as shoen and explained at : https://hackernoon.com/how-does-javascripts-math-random-generate-random-numbers-ef0de6a20131

function pseudoRandomNumber(a,b) {

    let s1 = a; 
    let s0 = b; 
    let state0 = s0;  
    let state1 = 0;

    s1 ^= s1 << (new Date().getTime() % 23);  // SHIFT
    s1 ^= s1 >> 17;  // SHIFT
    s1 ^= s0;
    s1 ^= s0 >> 26;  // SHIFT
    state1 = s1;

   return state0 + state1;
   
}
